//
//  ViewController.swift
//  museum
//
//  Created by Salma Tharwat on 4/13/20.
//  Copyright © 2020 Salma Tharwat. All rights reserved.
//
/// Copyright (c) 2018 Razeware LLC
///

import UIKit
import SceneKit
import ARKit
import CoreMedia
@available(iOS 12.0, *)
class ViewController: UIViewController {
  @IBOutlet var sceneView: ARSCNView!
  @IBOutlet weak var instructionLabel: UILabel!

  // Add configuration variables here:
  private var imageConfiguration: ARImageTrackingConfiguration?
  private var worldConfiguration: ARWorldTrackingConfiguration?

  override func viewDidLoad() {
    super.viewDidLoad()
    sceneView.delegate = self
   // setupImageDetection()
    setupObjectDetection()
    let scene = SCNScene()
    sceneView.scene = scene
    
  }

  private func addSerapisI(to node: SCNNode,referenceImage: ARReferenceImage) {
     print("first add")
     let cakeScene = SCNScene(named: "sreaaaa.dae")!
     let baseNode = cakeScene.rootNode.childNode(withName: "baseNode", recursively: true)!
      node.addChildNode(baseNode)

     self.sceneView.scene.rootNode.addChildNode(baseNode)
    print("last add")
  }
  private func addSerapisO(to node: SCNNode,referenceObject: ARReferenceObject) {
      print("first add")
      let cakeScene = SCNScene(named: "sreaaaa.dae")!
      let baseNode = cakeScene.rootNode.childNode(withName: "baseNode", recursively: true)!
       node.addChildNode(baseNode)
    
    
      self.sceneView.scene.rootNode.addChildNode(baseNode)
     print("last add")
   }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
   // if let configuration = imageConfiguration {
    //  sceneView.session.run(configuration)
    //}
    super.viewWillAppear(animated)
    if let configuration = worldConfiguration {
      sceneView.debugOptions = .showFeaturePoints
      sceneView.session.run(configuration)
      configuration.planeDetection = .horizontal
      sceneView.session.run(configuration)
    }

  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    sceneView.session.pause()

  }


  private func setupObjectDetection() {
    worldConfiguration = ARWorldTrackingConfiguration()
    guard let referenceImages = ARReferenceImage.referenceImages(
      inGroupNamed: "AR Images", bundle: nil) else {
        fatalError("Missing expected asset catalog resources.")
    }
    worldConfiguration?.detectionImages = referenceImages
    guard let referenceObjects = ARReferenceObject.referenceObjects(
      inGroupNamed: "AR Objects", bundle: nil) else {
      fatalError("Missing expected asset catalog resources.")
    }

    worldConfiguration?.detectionObjects = referenceObjects
  }

}

// MARK: -
extension ViewController: ARSessionDelegate {
  func session(_ session: ARSession, didFailWithError error: Error) {
    guard
      let error = error as? ARError,
      let code = ARError.Code(rawValue: error.errorCode)
      else { return }
    instructionLabel.isHidden = false
    switch code {
    case .cameraUnauthorized:
      instructionLabel.text = "Camera tracking is not available. Please check your camera permissions."
    default:
      instructionLabel.text = "Error starting ARKit. Please fix the app and relaunch."
    }
  }

  func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
    switch camera.trackingState {
    case .limited(let reason):
      instructionLabel.isHidden = false
      switch reason {
      case .excessiveMotion:
        instructionLabel.text = "Too much motion! Slow down."
      case .initializing, .relocalizing:
        instructionLabel.text = "ARKit is doing it's thing. Move around slowly for a bit while it warms up."
      case .insufficientFeatures:
        instructionLabel.text = "Not enough features detected, try moving around a bit more or turning on the lights."

      }
    case .normal:
      instructionLabel.text = "Point the camera at a dinsoaur."
    case .notAvailable:
      instructionLabel.isHidden = false
      instructionLabel.text = "Camera tracking is not available."
    }
  }
}

// MARK: -
extension ViewController: ARSCNViewDelegate {

  func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
    DispatchQueue.main.async { self.instructionLabel.isHidden = true }
    if let imageAnchor = anchor as? ARImageAnchor {
      handleFoundImage(imageAnchor, node)
      let refImage = imageAnchor.referenceImage
      addSerapisI(to: node, referenceImage: refImage)
      // hana
    } else if let objectAnchor = anchor as? ARObjectAnchor {
      print("Hi")
      handleFoundObject(objectAnchor, node)

      let refobj = objectAnchor.referenceObject
      addSerapisO(to: node, referenceObject: refobj)
    
      print("bye")
    }
  }

  private func handleFoundImage(_ imageAnchor: ARImageAnchor, _ node: SCNNode) {
    let name = imageAnchor.referenceImage.name!
    print("you found a \(name) image")
    let size = imageAnchor.referenceImage.physicalSize
     print("done I")

  }


  private func handleFoundObject(_ objectAnchor: ARObjectAnchor, _ node: SCNNode) {
   // 1
   let name = objectAnchor.referenceObject.name!
   print("You found a \(name) object")
   //registerGestureRecognizers()
    print("done O")

  }

}


